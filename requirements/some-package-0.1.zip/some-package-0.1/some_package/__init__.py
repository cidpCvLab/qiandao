print("Hello Python")
