__all__ = ('VERSION',)

VERSION = '0.7'
